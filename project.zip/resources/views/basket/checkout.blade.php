@extends('layouts.main')
@section('main')
    <h1>Оформление заказа</h1>
    <p>Здесь будет форма оформления</p>
@endsection
