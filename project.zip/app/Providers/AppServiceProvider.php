<?php

namespace App\Providers;

use App\Models\Basket;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        date_default_timezone_set('Asia/Yerevan');
        $basket_id = request()->cookie('basket_id');
        View::share('products', Basket::findOrFail($basket_id)->products);
    }
}
