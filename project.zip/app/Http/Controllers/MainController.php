<?php

namespace App\Http\Controllers;

use App\Models\Basket;
use App\Models\Product;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function index(Request $request)
    {
        $latest_shoes = Product::latest()->get();

        return view('home', compact('latest_shoes'));
    }
    public function contact()
    {
        return view('contact');
    }
}
