<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Product</h1>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex p-4">
                        <div class="mr-2">
                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-outline-success">Edit Product</a>
                        </div>
                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="submit" class="btn btn-outline-danger" value="Delete">
                        </form>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap">
                            <tbody>
                                <tr>
                                    <td>ID</td>
                                    <td><?php echo e($product->id); ?></td>
                                </tr>
                                <tr>
                                    <td>Title</td>
                                    <td><?php echo e($product->title); ?></td>
                                </tr>
                                <tr>
                                    <td>Description</td>
                                    <td><?php echo e($product->description); ?></td>
                                </tr>
                                <tr>
                                    <td>Content</td>
                                    <td><?php echo e($product->content); ?></td>
                                </tr>
                                <tr>
                                    <td>Count</td>
                                    <td><?php echo e($product->count); ?></td>
                                </tr>
                                <tr>
                                    <td>Price</td>
                                    <td><?php echo e($product->price); ?></td>
                                </tr>
                                <tr>
                                    <td>Cover IMG</td>
                                    <td>
                                        <img src="<?php echo e(asset('cover/'.$product->cover)); ?>" alt="multiple image"
                                        class="border border-blue-600" style="width: 200px">
                                    </td>
                                </tr>
                                <tr>
                                    <td>Images</td>
                                    <td>
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset('images/'.$item->image)); ?>" alt="multiple image"
                                            class="border border-blue-600" style="width: 200px">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gavaShopOld\project\resources\views/product/show.blade.php ENDPATH**/ ?>